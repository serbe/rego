export { EducationItem } from './item';
export { Educations } from './list';
